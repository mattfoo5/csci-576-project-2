Matthew Le
CSCI 576 Assignment 2

Compile program by typing javac MyCompression.java

Run program by typing java MyCompression file M N.
Program will only work if M = 2 because extra credit portion
was not completed. According to discussion posts, code will
be tested on one channel files only. Thus, only functionality
for one channel files was implemented. 

Examples of input parameters
file = image1-onechannel.rgb
M = 2
N = 16

Example of full valid command:
java MyCompression image1-onechannel.rgb 2 16
